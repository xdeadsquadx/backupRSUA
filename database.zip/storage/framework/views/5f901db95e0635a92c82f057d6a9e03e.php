<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="../styleLogin.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Login Form Using HTML And CSS Only</title>
</head>
<body>
	<div class="container" id="container">
        <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
		<div class="form-container log-in-container">
			<form action="<?php echo e(route('user.dashboard')); ?>" method="GET">
                <?php echo csrf_field(); ?>
				<h1 style="margin-bottom: 4%">Login Staff</h1>
                <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>"
                placeholder="Email">
				<input type="password" class="form-control" name="password" id="password"
                            placeholder="password">
				<button type="submit">Log In</button>
                <a href="" style="color: blue">kembali</a>
			</form>
		</div>
		<div class="overlay-container">
			<div class="overlay">
				<div class="overlay-panel overlay-right">
				</div>
			</div>
		</div>
	</div>
</body>
</html><?php /**PATH C:\magang\unair\resources\views/user/auth/login.blade.php ENDPATH**/ ?>